
from Aaaa import Aaaa

def main():
    start = Aaaa()
    start.start()

if __name__ == '__main__':
    main()
