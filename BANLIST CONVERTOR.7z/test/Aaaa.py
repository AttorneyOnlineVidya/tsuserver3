import hashlib
import json

class Aaaa:

    def start(self):
        x = input('Enter the server number: ')
        try:
            x = int(x)
        except ValueError:
            print("Input error, shutting down.")
            exit()
        hdid_list = {}
        try:
            with open('hd_ids.json', 'r', encoding='utf-8') as whole_list:
                hdid_list = json.loads(whole_list.read())
        except:
            print("hd_ids.json not found, or invalid. Shutting down.")
        ipid_list = {}
        try:
            with open('ip_ids.json', 'r', encoding='utf-8') as whole_list:
                ipid_list = json.loads(whole_list.read())
        except:
            print("ip_ids.json not found, or invalid. Shutting down.")
        banlist = []
        try:
            with open('old_banlist.json', 'r', encoding='utf-8') as whole_list:
             banlist = json.loads(whole_list.read())
        except:
            print("old_banlist.json not found, or invalid. Shutting down.")
        new_banlist = {}
        for ban in banlist:
            ip = list(ipid_list.keys())[list(ipid_list.values()).index(ban)]
            new_banlist[self.convert_hash(ip, x)] = True
        for hd in hdid_list:
            hold = []
            for ipn in hdid_list[hd]:
                ips = list(ipid_list.keys())[list(ipid_list.values()).index(ipn)]
                hold.append(self.convert_hash(ips, x))
            hdid_list[hd] = hold
        with open('hd_ids.json', 'w') as data:
            json.dump(hdid_list, data)

        with open('banlist.json', 'w') as data:
            json.dump(new_banlist, data)

    def convert_hash(self, ip, x):
            v =  ip + str(x)
            hash_object = hashlib.sha256(v.encode('utf-8'))
            hash = hash_object.hexdigest()[:12]
            return hash