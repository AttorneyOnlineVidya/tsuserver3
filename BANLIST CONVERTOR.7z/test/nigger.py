class slaveplantation:

    def __init__(self):
        self.niggers = []
        self.plants = 'cotton'